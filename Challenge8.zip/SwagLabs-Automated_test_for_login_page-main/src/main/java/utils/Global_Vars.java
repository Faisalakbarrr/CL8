package utils;

public class Global_Vars {

    public static final int DEFAULT_EXPLICIT_TIMEOUT = 10;

}
